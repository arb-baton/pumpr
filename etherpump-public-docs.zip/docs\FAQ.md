# FAQ

## Why does market cap sometimes show syncing?
It appears while the app is fetching fresh price and supply inputs.

## Why profile shows Guest sometimes?
Usually wallet/session data has not hydrated yet, or a profile API call failed and fell back.

## How to make profile load faster?
Cache profile summary by wallet and preload after wallet connect.

## Why are created tokens missing in profile?
Creator address mapping must match the launch record creator field exactly.

