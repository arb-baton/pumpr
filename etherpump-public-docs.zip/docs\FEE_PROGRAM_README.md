# Fee Program

Fee distribution in Etherpump is configured in basis points (bps).

## Components

- protocol fee
- creator fee
- buyback/reserve fee (optional)

## Rules

- Total configured fee must stay under platform max.
- Invalid or zero recipient addresses are rejected.
- Distribution events are recorded for audit/debug.

