# Coin Creation

Launch creation flow:

1. Submit token metadata (name, symbol, image, description).
2. Set creator wallet address.
3. Deploy token and register launch record.
4. Optionally seed initial liquidity.

## Required inputs

- creator wallet
- token metadata
- initial supply configuration
- quote asset choice

