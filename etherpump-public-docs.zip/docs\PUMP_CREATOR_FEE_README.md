# Creator Fee Update

This file describes creator fee behavior for Etherpump launches.

## What creator fee means

For each buy/sell, a configured percentage is allocated to the launch creator.

## Data model

- `creatorAddress`
- `creatorFeeBps`
- `accruedCreatorFees`
- `claimedCreatorFees`

## Behavior

- Fees accrue on qualifying trades.
- Fees can be claimed by the creator wallet.
- Frontend should show pending and claimed balances separately.

## Safety checks

- Validate creator address at launch creation.
- Reject zero/invalid recipient addresses.
- Enforce max fee bps server-side.

