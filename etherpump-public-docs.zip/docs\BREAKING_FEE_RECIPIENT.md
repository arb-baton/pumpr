# Breaking Change: Fee Recipient Routing

Etherpump moved to explicit fee-recipient routing for trade execution.

## What changed

- Fee recipient addresses are validated before routing.
- Recipient config is now read from the latest backend config endpoint.

## Action required

- Update your integration to pass current fee-recipient metadata from API.
- Do not hardcode old recipient lists.

