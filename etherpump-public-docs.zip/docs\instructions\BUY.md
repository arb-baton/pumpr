# Buy

Buy flow for an Etherpump token:

1. Resolve launch by token address.
2. Fetch quote and min-out from API/router.
3. Submit wallet transaction.
4. Wait for confirmation.
5. Refresh token + profile data.

## Required inputs

- buyer wallet address
- token address
- quote amount (ETH or supported quote token)
- slippage bps

