# Etherpump Program

This document describes the Etherpump EVM-side launch flow at a high level.

## Overview

Etherpump supports:
- token creation
- launch metadata storage
- buy/sell routing through Uniswap-compatible liquidity
- creator attribution and creator rewards
- fee recipient distribution

## Core Concepts

- `launch`: one created token + its metadata + creator address.
- `creator`: wallet that created the launch.
- `quote asset`: trading quote asset (for example ETH/WETH or configured ERC-20 quote).
- `market cap`: computed from current price and configured circulating supply model.

## Lifecycle

1. Create token and launch metadata.
2. Seed initial liquidity.
3. Enable trading.
4. Track volume, fees, and creator rewards.
5. Expose data to frontend/profile endpoints.

## Integration Notes

- Keep RPC endpoints healthy and use fallback RPCs.
- Cache hot launch data for fast home/profile loads.
- Recompute market cap from live price source on refresh.
- Show pending state only while fresh data is being fetched.

## Operational Notes

- If an upstream RPC is degraded, fallback RPC should serve reads.
- If external market source is delayed, keep previous value with a stale marker instead of hard defaulting.
- Profile pages should resolve by creator address and return created launches quickly from indexed storage.

