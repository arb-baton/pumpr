# Integration Guide

Use your backend service as the primary integration layer for Etherpump.

## Recommended flow

1. Read launch list from API.
2. Read token details by launch id or token address.
3. Execute buy/sell through wallet + router path.
4. Refresh launch/profile data after transaction confirmation.

## Why API-first

- lower latency than raw chain scans
- normalized creator/launch data
- consistent market cap calculation

