﻿# etherpump-public-docs

Public technical documentation for the Etherpump ecosystem.

This repository mirrors the original public docs layout, but the written content is adapted for Etherpump branding and Etherpump-facing docs.

## What this repo contains

- `docs/`: markdown documentation for protocol behavior, fee programs, and instruction references.
- `docs/instructions/`: per-instruction account lists, examples, and implementation notes.
- `idl/`: intentionally omitted in this package.

## Core docs

- [Etherpump Program](docs/PUMP_PROGRAM_README.md)
- [Creator fee update](docs/PUMP_CREATOR_FEE_README.md)
- [Fee program docs](docs/FEE_PROGRAM_README.md)
- [Fee recipients](docs/FEE_RECIPIENTS.md)
- [FAQ](docs/FAQ.md)

## Instruction references

- [Coin creation](docs/instructions/COIN_CREATION.md)
- [Buy](docs/instructions/BUY.md)
- [Sell](docs/instructions/SELL.md)

## Notes

- This repo is documentation-focused.
- Program addresses and SDK package names shown in docs are placeholders unless your deployment has set those exact values.
- Before publishing externally, review any migrated examples to ensure they match your live Etherpump contracts and SDKs.


