# Sell

Sell flow for an Etherpump token:

1. Resolve launch/token metadata.
2. Fetch quote and min-out.
3. Submit sell transaction from wallet.
4. Confirm on-chain.
5. Refresh holdings, market cap, and profile.

## Required inputs

- seller wallet address
- token address
- token amount
- slippage bps

