# Fee Recipients

This file should contain the current fee-recipient addresses used by your Etherpump deployment.

## Example structure

- `protocol`: `0x...`
- `creatorFees`: `0x...`
- `buybackReserve`: `0x...`

Keep this in sync with backend environment/config values.

